package org.dkit.logued.serviceexample

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import android.widget.Toast

class MyService : Service() {

    // allows a client (Activity) to bind to this service.
    //
    override fun onBind(intent: Intent): IBinder {
        TODO("Return the communication channel to the service.")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("Service","MyService... onStartCommand() called.")
        Toast.makeText(this, "MyService started - onStartCommand() called", Toast.LENGTH_LONG).show()

        doWork()

        return START_STICKY
    }

    // called when activity issues a stopService(Intent) request
    override fun onDestroy() {
        Log.d("Service","MyService... onDestroy() called.")
        super.onDestroy()
        Toast.makeText(this, "MyService destroyed - onDestroy() called", Toast.LENGTH_LONG).show()

    }

    fun doWork()
    {
//        try {
//            Thread.sleep(5000)
//        }catch (e: InterruptedException){}

        // Running a task in a separate thread
        // will prevent this Service from blocking the UI
        // in the MainActivity
        //
        val thread = object : Thread() {
            override fun run() {
                Log.i("Service", "MyService ... in doWork() - Thread Started")
                try {
                    // simulated long-running task
                    sleep(5000)

                    //When finished - send a Broadcast to notify the Activity
                    val broadcastIntent = Intent()
                    //add any extras that want to be returned - nothing in this case.
                    //set user-defined action
                    broadcastIntent.action = "WORK_COMPLETE_ACTION"
                    //broadcast the intent
                    baseContext.sendBroadcast(broadcastIntent)
                    // the broadcast is delivered, by Android system, to any BroadcastReceivers
                    // that have a corresponding intent-filter

                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
                Log.i("Service", "MyService ... in doWork() - Thread Finished")
            }
        }
        thread.start()

    }
}