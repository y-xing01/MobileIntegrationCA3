package org.dkit.logued.rssexamples

class RssItemViewHolder constructor(val title: String, val description: String,val pubDate: String,val copyright: String) {
}